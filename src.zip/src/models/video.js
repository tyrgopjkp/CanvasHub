// models/video.js
import { DataTypes, Model } from 'sequelize';
import sequelize from '../utils/database.js'; // Путь к вашему экземпляру Sequelize

class Video extends Model {}

Video.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  videoPath: {
    type: DataTypes.STRING,
    allowNull: false
  },
   thumbnailPath: {
        type: DataTypes.STRING,
        allowNull: true
   },
  title: {
    type: DataTypes.STRING
  },
  description: {
    type: DataTypes.TEXT
  },
   createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW,
      },
}, {
  sequelize,
  modelName: 'video',
  timestamps: false,
});

export default Video;
