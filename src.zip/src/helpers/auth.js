// helpers/auth.js
export const getToken = () => {
    const token = localStorage.getItem('token');
    console.log('Token from getToken:', token); // Added console.log
    return token;
};