import React, { useState } from 'react';
import './ProfileEditPage.css'

function ProfileEditPage() {
    const [username, setUsername] = useState("User Name"); // По умолчанию
    const [avatar, setAvatar] = useState(null);

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handleAvatarChange = (event) => {
        setAvatar(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
      event.preventDefault();

      const formData = new FormData();
      formData.append('username', username);
      if(avatar){
        formData.append('avatar', avatar);
      }

      try {
        const response = await fetch('http://localhost:5000/api/profile/edit', {
          method: 'POST',
          body: formData,
        });

          if(response.ok){
              alert('Profile updated successfully');
          } else {
                alert('Failed to update profile');
           }
      } catch(error){
          console.error("Error updating profile:", error);
      }
    };

  return (
    <div className="profile-edit-page">
      <h1>Edit Profile</h1>
      <form onSubmit={handleSubmit}>
          <div className="form-group">
              <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={handleUsernameChange}
            />
        </div>
           <div className="form-group">
          <label htmlFor="avatar">Avatar:</label>
          <input
            type="file"
            id="avatar"
            onChange={handleAvatarChange}
          />
        </div>
          <button type="submit">Save Changes</button>
      </form>
    </div>
  );
}

export default ProfileEditPage;