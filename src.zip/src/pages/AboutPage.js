import React from 'react';

function AboutPage() {
    return <h1> О нас</h1>;
}

export default AboutPage;