import React from 'react';
import './ProfilePage.css';

const ProfilePage = ({ user }) => {
    return (
        <div className="profile-container">
            <div className="profile-header">
               {user && user.avatarPath && (
                    <img
                         src={user.avatarPath}
                         alt="User Avatar"
                        className="profile-header-avatar"
                    />
                )}
                {user && (
                    <h2 className="profile-header-username">{user.username}</h2>
               )}
            </div>
            {user && (
                <div className='profile-info'>
                   <p>Email: {user.email}</p>
                </div>
           )}
       </div>
   );
};

export default ProfilePage;