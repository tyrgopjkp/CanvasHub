import React, { useState, useEffect } from 'react';
import './HomePage.css';
import { Link } from 'react-router-dom';

const HomePage = ({ auth, user }) => {
    const [activeButton, setActiveButton] = useState('video');
    const [videos, setVideos] = useState([]);

    const handleButtonClick = (buttonName) => {
        setActiveButton(buttonName);
    };

    useEffect(() => {
        const fetchVideos = async () => {
            if (activeButton === 'video') {
                try {
                   const response = await fetch('http://localhost:5000/api/videos');
                    if (!response.ok) {
                        const message = await response.json();
                        throw new Error(message.message);
                    }
                    const data = await response.json();
                    setVideos(data);
                } catch (error) {
                    console.error('Ошибка получения списка видео', error);
                    alert(`Ошибка получения списка видео: ${error.message}`);
                }
            } else {
                setVideos([]);
            }
        };
        fetchVideos();
    }, [activeButton]);

    return (
        <div className="home-page-container">
            <div className="content-buttons">
                <button
                    className={`content-button ${activeButton === 'video' ? 'active' : ''}`}
                    onClick={() => handleButtonClick('video')}
                >
                    Видео
                </button>
                <button
                    className={`content-button ${activeButton === 'image' ? 'active' : ''}`}
                    onClick={() => handleButtonClick('image')}
                >
                    Изображение
                </button>
                <button
                    className={`content-button ${activeButton === 'message' ? 'active' : ''}`}
                    onClick={() => handleButtonClick('message')}
                >
                    Сообщение
                </button>
                <button
                    className={`content-button ${activeButton === 'draw' ? 'active' : ''}`}
                    onClick={() => handleButtonClick('draw')}
                >
                    Рисунок
                </button>
            </div>
            {activeButton === 'video' && (
                <div className="video-list">
                    {videos.map(video => (
                        <div key={video.id} className="video-item">
                            <Link to={`/video/${video.id}`} className="video-link">
                                <img src={`${video.coverUrl}`} alt={video.title} className="video-thumbnail" />
                                <div className="video-info">
                                    <h3>{video.title}</h3>
                                    <div className="video-author">
                                        <img src={`${video.authorAvatar}`} alt={video.authorUsername} className="author-avatar" />
                                        <span>{video.authorUsername}</span>
                                    </div>
                                </div>
                            </Link>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default HomePage;