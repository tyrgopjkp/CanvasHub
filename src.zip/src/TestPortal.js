import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

const TestModal = ({ onClose }) => {
    return ReactDOM.createPortal(
      <div style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
         <div style={{ backgroundColor: 'white', padding: '20px' }}>
             <p>Это модальное окно</p>
              <button onClick={onClose}>Закрыть</button>
         </div>
       </div>,
        document.getElementById('modal-root')
    );
};

const TestPortal = () => {
    const [showModal, setShowModal] = useState(false);
   return (
      <div>
         <button onClick={() => setShowModal(true)}>Открыть модальное окно</button>
        {showModal && <TestModal onClose={() => setShowModal(false)} />}
      </div>
    );
};

export default TestPortal;