import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import CreateContentModal from './components/CreateContentModal';
import VideoPage from './components/VideoPage';
import сhat from './components/chat';
import UserLoader from "./components/UserLoader.js";


function App() {
    const [showCreateModal, setShowCreateModal] = useState(false);
    const handleCreateContentClick = () => {
        setShowCreateModal(true)
    };
    const handleCloseCreateContentModal = () => {
        setShowCreateModal(false);
    };
     const fetchUserData = async (token) => {
        console.log("fetchUserData: Started");
        try {
            console.log("fetchUserData: Try block entered");
            const response = await fetch('http://localhost:5000/api/me', {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            });
            console.log("fetchUserData: Response received", response);

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: "Ошибка сети или сервера" }));
                throw new Error(errorData.message || response.statusText);
            }
            const data = await response.json();
            return data.user;
        } catch (error) {
            console.error("Error fetching user data:", error);
            localStorage.removeItem('token');
            return null;
        }
    };


   return (
        <Router>
            <UserLoader fetchUserData={fetchUserData}>
                {({auth}) => (
                 <div>
                    <Navbar handleCreateContentClick={handleCreateContentClick} />
                    <Routes>
                       <Route path="/" element={<HomePage auth={auth} />} />
                       <Route path="/profile" element={<ProfilePage />} />
                        <Route path="/video/:id" element={<VideoPage />} />
                        <Route path="/chat" element={<сhat/>} />
                     </Routes>
                       {showCreateModal &&
                           <CreateContentModal onClose={handleCloseCreateContentModal} />
                         }
                   </div>
                )}
            </UserLoader>
       </Router>
  );
}

export default App;