import React, { createPortal, useState } from 'react';
import ReactDOM from 'react-dom';

const MinimalModal = ({ onClose }) => {
  return createPortal(
    <div style={{ position: 'fixed', top: 0, left: 0, backgroundColor: 'rgba(0,0,0,0.5)', width: '100%', height: '100%', display:'flex', justifyContent:'center', alignItems:'center'}}>
      <div style={{backgroundColor:'white', padding:'20px'}}>
        <p>Это минимальный портал</p>
        <button onClick={onClose}>Закрыть</button>
      </div>
    </div>,
    document.getElementById('modal-root')
  );
};

const MinimalExample = () => {
  const [showModal, setShowModal] = useState(false);
  return (
    <div>
      <h1>Минимальный пример</h1>
      <button onClick={() => setShowModal(true)}>Открыть портал</button>
      {showModal && <MinimalModal onClose={() => setShowModal(false)} />}
    </div>
  );
};
export default MinimalExample;