import React, { useState } from 'react';
import './VideoUploadForm.css';

const VideoUploadForm = ({ onClose, onVideoUpload }) => {
    const [videoFile, setVideoFile] = useState(null);
    const [coverFile, setCoverFile] = useState(null);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [errorMessage, setErrorMessage] = useState('');

    const handleVideoChange = (e) => {
        setVideoFile(e.target.files[0]);
    };

    const handleCoverChange = (e) => {
        setCoverFile(e.target.files[0]);
    };

    const handleTitleChange = (e) => {
        setTitle(e.target.value);
    };

    const handleDescriptionChange = (e) => {
        setDescription(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setErrorMessage('');
        if (!videoFile || !coverFile || !title || !description) {
            setErrorMessage("Пожалуйста, заполните все поля формы.");
            return;
        }

        const token = sessionStorage.getItem('token');
         if(!token){
            setErrorMessage('Вы не авторизованы.')
             return;
        }

        const formData = new FormData();
        formData.append('video', videoFile);
        formData.append('cover', coverFile);
        formData.append('title', title);
        formData.append('description', description);


        try {
            const response = await fetch('http://localhost:5000/api/videos/upload', {
                method: 'POST',
                body: formData,
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Ошибка загрузки видео');
            }

            const data = await response.json();
            onVideoUpload(data);
            onClose();
            alert('Видео успешно загружено!');

        } catch (error) {
            console.error("Ошибка загрузки видео:", error);
            setErrorMessage(`Ошибка загрузки видео: ${error.message}`);
        }
    };

    return (
        <div className="video-upload-form-container">
            <div className="modal-content">
                <h2>Загрузить видео</h2>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="video">Видео</label>
                        <input type="file" id="video" accept="video/*" onChange={handleVideoChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="cover">Обложка видео (1280x720)</label>
                        <input type="file" id="cover" accept="image/*" onChange={handleCoverChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="title">Название видео</label>
                        <input type="text" id="title" value={title} onChange={handleTitleChange} required />
                    </div>
                    <div className="form-group">
                        <label htmlFor="description">Описание видео</label>
                        <textarea id="description" value={description} onChange={handleDescriptionChange} required></textarea>
                    </div>
                    {errorMessage && <p className="error-message">{errorMessage}</p>}
                    <button type="submit" className="submit-button">Загрузить</button>
                    <button type="button" className="close-button" onClick={onClose}>Закрыть</button>
                </form>
            </div>
        </div>
    );
};

export default VideoUploadForm;
