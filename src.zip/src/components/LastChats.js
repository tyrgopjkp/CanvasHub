import React, { useState, useEffect } from 'react';
import { getToken } from '../helpers/auth';
import './LastChats.css';

const LastChats = ({ onUserSelect }) => {
    const [lastChats, setLastChats] = useState([]);

    const fetchLastChats = async () => {
        try {
            const token = getToken();
            const userId = localStorage.getItem('userId');
            const response = await fetch(`/api/messages/all/${userId}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setLastChats(data);
        } catch (error) {
            console.error('Could not fetch last chats:', error);
        }
    };

    useEffect(() => {
        fetchLastChats();
    }, []);


    const handleChatClick = (user) => {
        onUserSelect(user);
    };

    return (
        <div className="last-chats">
            <h2>Последние чаты</h2>
            <ul>
                {lastChats.map((chat) => (
                    <li key={chat.userId} onClick={() => handleChatClick(chat)} className="last-chat-item">
                        <div className="chat-user">{chat.username}</div>
                        <div className="last-message">{chat.lastMessage}</div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default LastChats;