
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import VideoPlayer from '../components/VideoPlayer';
/*import './VideoPage.css';*/


const VideoPage = () => {
    const { id } = useParams();
    const [video, setVideo] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);


    useEffect(() => {
        const fetchVideo = async () => {
            setLoading(true);
             setError(null);
             try {
                 const response = await fetch(`http://localhost:5000/api/videos`);
                  if(!response.ok){
                      const message = await response.json();
                      throw new Error(message.message)
                 }
                const data = await response.json();
                const foundVideo = data.find(vid => vid.id === parseInt(id));
                if(foundVideo){
                   setVideo(foundVideo);
                }else {
                     throw new Error("Видео не найдено")
                 }
             } catch (error){
                 console.error("Ошибка загрузки видео:", error);
                setError(error.message)
             } finally {
                 setLoading(false)
             }
        };

         fetchVideo();
    }, [id]);

    if(loading){
         return <div>Загрузка видео...</div>
    }

     if(error){
        return <div className="error-message">Ошибка загрузки видео: {error}</div>;
    }
    if (!video) {
         return <div>Видео не найдено</div>;
    }


    return (
        <div className="video-page">
            <h2>{video.title}</h2>
            <div className="video-container">
                 <VideoPlayer videoUrl={`${video.videoUrl}`} />
            </div>
        </div>
    );
};

export default VideoPage;