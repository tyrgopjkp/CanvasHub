import React from 'react';
import './VideoItem.css';
import { Link } from 'react-router-dom';

const VideoItem = ({ video, onVideoClick }) => {
    return (
        <div className="video-item" >
             <div onClick={() => onVideoClick(video)}>
              <img src={video.coverUrl} alt={video.title} className="video-cover" />
           </div>
            <div className="video-details">
               <h3 onClick={() => onVideoClick(video)} className="video-title">{video.title}</h3>
                <div className="author-info">
                    <Link to={`/profile/${video.author.username}`} className="author-link">
                        <img src={video.author.avatarPath} alt={video.author.username} className="author-avatar" />
                      <span className="author-username">{video.author.username}</span>
                   </Link>
                 </div>
            </div>
        </div>
    );
};

export default VideoItem;