import React from 'react';
import './Modal.css'; // Import стилей для модального окна

const Modal = ({ children, onClose }) => {
  return (
    <div className="modal-overlay">
        <div className="modal-content">
             <button style={{position: 'absolute', right: 0, top: 10,  padding: 0, backgroundColor: 'transparent', border: 'none'}} onClick={onClose}>X</button>
          {children}
        </div>
    </div>
  );
};

export default Modal;