import React from 'react';
import { FaComment } from 'react-icons/fa';
const ChatIcon = () => {
    return <FaComment size={20} />;
};
export default ChatIcon;