import React, { useState, useEffect, useCallback } from 'react';
import './ChatWindow.css';
import { getToken } from '../helpers/auth';

const ChatWindow = ({ selectedUser }) => {
    console.log("ChatWindow: selectedUser prop:", selectedUser);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');

    const fetchMessages = useCallback(async () => {
        try {
             console.log("ChatWindow: fetchMessages: selectedUser:", selectedUser);
            if (!selectedUser) {
                console.log("ChatWindow: fetchMessages: selectedUser is null");
                return;
            }
            const token = getToken();
             console.log('Token before fetching messages:', token);
             const response = await fetch(`http://localhost:5000/api/messages/${selectedUser.id}`, {
                headers: {
                    'Authorization': `Bearer ${token}`,
                },
            });

             if (!response.ok) {
                const errorData = await response.json().catch(() => ({ message: "Ошибка сети или сервера" }));
                 throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
               console.log("ChatWindow: fetchMessages: Messages received:", data);
             setMessages(data.messages);
        } catch (error) {
             console.error("Could not fetch messages:", error);
        }
    }, [selectedUser]);


    useEffect(() => {
        console.log("ChatWindow: useEffect: fetchMessages triggered with selectedUser:", selectedUser);
        fetchMessages();
       }, [fetchMessages, selectedUser]);


    const handleSendMessage = async () => {
        if(newMessage.trim() === ''){
            return;
        }
        try {
            const token = getToken();
            console.log('Token before sending message:', token);
             const response = await fetch('http://localhost:5000/api/messages', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
              },
              body: JSON.stringify({
                receiverId: selectedUser.id,
                text: newMessage,
              }),
            });
             if (!response.ok) {
                 const errorData = await response.json().catch(() => ({ message: "Ошибка при отправке сообщения" }));
                  throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
             }
              await fetchMessages();
            setNewMessage('');
        } catch (error) {
            console.error("Could not send message:", error);
        }
    };

    const handleInputChange = (e) => {
        setNewMessage(e.target.value)
    };

    return (
        <div className="chat-window">
            <div className="chat-header">
                {selectedUser ? `Чат с ${selectedUser.username}` : 'Выберите пользователя для чата'}
            </div>
            <div className="chat-messages">
                 {messages && messages.map((message) => (
                   <div
                        key={message._id} // Уточните, какое поле является уникальным идентификатором
                        className={`message ${message.senderId === localStorage.getItem('userId') ? 'message-sent' : 'message-received'}`}
                    >
                       <div className="message-text">{message.text}</div>
                         <div className="message-time">{new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                   </div>
                ))}
            </div>
            <div className="chat-input">
                <input
                    type="text"
                    placeholder="Введите сообщение..."
                    value={newMessage}
                    onChange={handleInputChange}
                    className="input-message"
                />
                 <button onClick={handleSendMessage} className="button-send">Отправить</button>
            </div>
        </div>
    );
};

export default ChatWindow;