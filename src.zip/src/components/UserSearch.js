import React, { useState, useEffect } from 'react';
import './UserSearch.css';

const UserSearch = ({ onUserSelect }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [allUsers, setAllUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await fetch('http://localhost:5000/api/users');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                setAllUsers(data);
            } catch (error) {
                console.error("Could not fetch users:", error);
            }
        };
        fetchUsers();
    }, []);

    useEffect(() => {
        const results = allUsers.filter(user =>
            user.username.toLowerCase().includes(searchTerm.toLowerCase())
        );
        setSearchResults(results);
    }, [searchTerm, allUsers]);

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    const handleUserClick = (user) => {
        onUserSelect(user);
    };

    return (
        <div className="user-search">
            <div className="search-input-container">
                <input
                    type="text"
                    placeholder="Поиск пользователей..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    className="search-input"
                />
            </div>
            <div className="search-results-container">
                <ul className="search-results">
                    {searchResults.map(user => (
                        <li key={user.id} onClick={() => handleUserClick(user)} className="search-result">
                            {user.username}
                        </li>
                    ))}
                    {!searchTerm && <li className="no-results">Введите никнейм для поиска</li>}
                    {searchTerm && searchResults.length === 0 && <li className="no-results">Пользователь не найден</li>}
                </ul>
            </div>
        </div>
    );
};

export default UserSearch;