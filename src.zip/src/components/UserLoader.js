import React, { useState, useEffect, useCallback, createContext, useContext } from 'react';

const UserContext = createContext();

const UserLoader = ({ children, fetchUserData }) => {
    const [auth, setAuth] = useState(false);
    const [user, setUser] = useState(null);
    const [accounts, setAccounts] = useState([]);
    const [currentAccount, setCurrentAccount] = useState(null);
    const [loading, setLoading] = useState(true);


    const areAccountsEqual = useCallback((arr1, arr2) => {
        if (arr1.length !== arr2.length) return false;
        for (let i = 0; i < arr1.length; i++) {
            if (arr1[i].username !== arr2[i].username || arr1[i].token !== arr2[i].token) {
                return false;
            }
        }
        return true;
    }, []);

    useEffect(() => {
        console.log("UserLoader: useEffect: Started");
        const storedTheme = localStorage.getItem('theme');
        if (storedTheme) {
            document.body.classList.toggle('dark', storedTheme === 'dark');
        }
        const storedAccounts = localStorage.getItem('accounts');
        if (storedAccounts) {
            setAccounts(JSON.parse(storedAccounts));
        }

        const storedCurrentAccount = localStorage.getItem('currentAccount');
        if (storedCurrentAccount) {
            setCurrentAccount(JSON.parse(storedCurrentAccount));
        }

        const loadUserData = async () => {
            setLoading(true);
             const token = localStorage.getItem('token');
                if(!token){
                  setAuth(false);
                  setLoading(false)
                 return;
               }
              console.log("UserLoader: useEffect: token:", token);
            try {
                const response = await fetch('http://localhost:5000/api/me', {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                    },
                });
                if (!response.ok) {
                    // Обработка ошибки авторизации
                     setAuth(false);
                    setUser(null);
                   localStorage.removeItem('token');
                    throw new Error('Ошибка авторизации');
                }
                const data = await response.json();
                 const user = data.user;
                  console.log("UserLoader: useEffect: user:", user);
                if (user) {
                    setAuth(true);
                    setUser(user);
                    setCurrentAccount(user.username);
                     const updatedAccounts = accounts.map(acc => {
                       if (acc.username === user.username) {
                         return { ...acc, token: token };
                         }
                     return acc;
                  });

                if (!areAccountsEqual(accounts, updatedAccounts)) {
                    setAccounts(updatedAccounts.some(acc => acc.username === user.username) ? updatedAccounts : [...updatedAccounts, { username: user.username, token: token }]);
                    }
                } else {
                 console.error("UserLoader: useEffect: user is null");
             }
         } catch (error) {
            console.error("UserLoader: Error fetching user data", error);
             } finally {
                setLoading(false)
           }
       };
       loadUserData();
    }, [ fetchUserData, accounts]); // Убрали areAccountsEqual

    useEffect(() => {
        localStorage.setItem('accounts', JSON.stringify(accounts));
        localStorage.setItem('currentAccount', JSON.stringify(currentAccount));
    }, [accounts, currentAccount]);


     if (loading) {
        return <p>Loading...</p>
    }

   return (
        <UserContext.Provider value={{
            auth, user, accounts, setAccounts, currentAccount, setCurrentAccount
         }}>
            {children({ auth, user, accounts, setAccounts, currentAccount, setCurrentAccount })}
        </UserContext.Provider>
   );
};


export default UserLoader;
export const useUser = () => useContext(UserContext);