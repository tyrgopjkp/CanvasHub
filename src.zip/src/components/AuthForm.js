import React, { useState } from 'react';
import './AuthForm.css';

const AuthForm = ({ onAuth, isLogin, setShowAuthForm, setAuth, setUser, accounts, setAccounts, setCurrentAccount, fetchUserData }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const avatarPath = '/uploads/avatars/default_avatar.png';
    const [error, setError] = useState('');

    const handleAuthSubmit = async (authData) => {
        try {
            const endpoint = isLogin ? '/api/login' : '/api/register';
            const response = await fetch(`http://localhost:5000${endpoint}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(authData),
            });
            if (!response.ok) {
                const message = await response.json();
                throw new Error(message.message);
            }
            const data = await response.json();
             localStorage.setItem('token', data.token);
            console.log('Token saved to localStorage:', data.token);
            onAuth(data.user, accounts, setAccounts, setCurrentAccount);
        } catch (err) {
            console.error("Error auth:", err);
            setError(err.message);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        let body;
        if (isLogin) {
            body = { username, password };
        } else {
            body = { username, password, avatarPath };
        }
        await handleAuthSubmit(body);
    };

    return (
        <div className="auth-form-container">
            <form className="auth-form" onSubmit={handleSubmit}>
                <h2>{isLogin ? 'Вход' : 'Регистрация'}</h2>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                    id="username"
                    name="username"
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    id="password"
                    name="password"
                />
                <button type="submit">{isLogin ? 'Вход' : 'Регистрация'}</button>
                {error && <p style={{ color: 'red' }}>{error}</p>}
            </form>
        </div>
    );
};

export default AuthForm;