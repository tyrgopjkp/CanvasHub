import React, { useState, useRef } from 'react';

const EditProfileModal = ({ onClose, user, onUpdateUser }) => {
  console.log('EditProfileModal rendered')
    const [userName, setUserName] = useState(user.username || '');
    const [avatar, setAvatar] = useState(user.avatarPath || null);
    const avatarInputRef = useRef(null);


   const handleAvatarChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setAvatar(reader.result);
            };
            reader.readAsDataURL(file);
        } else {
            setAvatar(null);
        }
    };

    const handleRemoveAvatar = () => {
        setAvatar(null);
    };


   const handleSave = async () => {
        try {
            const token = localStorage.getItem('token');
            console.log(user)
            const response = await fetch(`http://localhost:5000/api/users/${user.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({ username: userName, avatarPath: avatar }),
        });

            if (!response.ok) {
                const message = await response.json();
                throw new Error(message.message);
            }

            const data = await response.json();
            const updatedUser = { ...user, username: data.user.username, avatarPath: data.user.avatarPath };
            onUpdateUser(updatedUser);
            onClose();
        } catch (err) {
            console.error("Profile update error:", err);
            alert(err.message);
        }
    };

  return (
        <div className="modal">
            <div className="modal-content">
                <h2>Редактировать профиль</h2>
                <div className="modal-avatar-container">
                    {avatar ? (
                        <img src={avatar} alt="User Avatar" className="modal-avatar" />
                    ) : (
                        <div className="modal-avatar-placeholder">Выберите аватар</div>
                    )}
                  <div className="modal-avatar-buttons">
                        <input
                           type="file"
                            accept="image/*"
                           onChange={handleAvatarChange}
                           style={{ display: 'none' }}
                          ref={avatarInputRef}
                           />
                           <button className="modal-button" onClick={() => avatarInputRef.current.click()}>
                                 Загрузить аватар
                           </button>
                           <button className="modal-button" onClick={handleRemoveAvatar}>
                                Удалить аватар
                            </button>
                     </div>
                 </div>
                 <input
                    type="text"
                     placeholder="Имя пользователя"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                  <div className="modal-button-container">
                       <button className="modal-button" onClick={handleSave}>Сохранить</button>
                      <button className="modal-button" onClick={onClose}>Отмена</button>
                   </div>
             </div>
       </div>
   );
};

export default EditProfileModal;