import React, { useState, useRef, useCallback } from 'react';
import './Navbar.css';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import AuthForm from './AuthForm.js';
import EditProfileModal from './EditProfileModal.js';
import ChatIcon from './ChatIcon';

const Navbar = ({ handleCreateContentClick, auth, user, accounts, setAccounts, currentAccount, setCurrentAccount }) => {
    const [showAuthForm, setShowAuthForm] = useState(false);
    const [isLogin, setIsLogin] = useState(true);
    const [showLogout, setShowLogout] = useState(false);
    const userSectionRef = useRef(null);
    const location = useLocation();
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const navigate = useNavigate();

    const handleChatClick = () => {
        navigate('/chat');
    };

    const handleAuth = (userData, accounts, setAccounts, setCurrentAccount) => {
        try {
            setShowAuthForm(false);
            localStorage.setItem('userId', userData.id);

            // Обновляем accounts, учитывая возможные дубликаты
            const updatedAccounts = [...accounts, { username: userData.username, token: localStorage.getItem('token') }]
                .filter((item, index, self) => index === self.findIndex((t) => (t.username === item.username)));
            setAccounts(updatedAccounts);
            localStorage.setItem('accounts', JSON.stringify(updatedAccounts));
            console.log('accounts saved to localStorage:', updatedAccounts);
            setCurrentAccount(userData.username);
            localStorage.setItem('currentAccount', JSON.stringify(userData.username));
            console.log('currentAccount saved to localStorage:', userData.username);

        } catch (error) {
            console.error("Error auth:", error);
        }
    };

   const toggleLogoutDropdown = () => {
        setShowLogout(!showLogout);
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        setShowLogout(false);
    };

    const handleModalOpen = () => {
      setIsModalOpen(true);
    };

    const handleModalClose = () => {
      setIsModalOpen(false);
    };

    const handleEditProfile = (updatedUser) => {
        console.log("handleEditProfile", updatedUser)
    };

    const toggleAuthForm = (login) => {
      setIsLogin(login)
      setShowAuthForm(true);
    };

    const closeAuthForm = () => {
      setShowAuthForm(false);
    };
     const toggleLogout = () => {
        setShowLogout(!showLogout);
    };

    const toggleTheme = () => {
        setIsDarkMode(!isDarkMode);
    };

   const isProfilePage = location.pathname === '/profile';
    const cacheBuster = Date.now();

    const handleAddAccount = () => {
       setIsLogin(false)
       setShowAuthForm(true);
   };

    const handleProfileClick = () => {
        if(!isProfilePage){
            window.location.href = `/profile?t=${cacheBuster}`;
        }
    };

    const handleSwitchAccount = async (account) => {
       if(!account || !account.token) return;
        localStorage.setItem('token', account.token);
    };

    return (
        <nav className={`navbar ${isDarkMode ? 'dark' : ''}`}>
            <div className="logo">
                <Link to="/">CanvasHub</Link>
            </div>
             {auth ? (
                <div className="user-section" ref={userSectionRef}>
                     <span className="create-content-button" onClick={handleCreateContentClick}>Создать контент</span>
                     <div className="user-info" onClick={toggleLogout}>
                        {user && user.avatarPath && (
                            <img
                                src={user.avatarPath}
                                alt="User Avatar"
                                className="user-avatar"
                            />
                        )}
                    </div>
                      <span className="username" onClick={toggleLogout}>
                        {user ? user.username : 'User'}
                   </span>
                   <Link to="/chat" onClick={handleChatClick}><ChatIcon /></Link>
                    {showLogout && (
                        <div className="logout-menu">
                            {isModalOpen && <EditProfileModal onClose={handleModalClose} user={user} onUpdateUser={handleEditProfile}/>}
                            <button onClick={handleLogout} className="logout-button">Logout</button>
                            <Link onClick={handleProfileClick} to={isProfilePage ? "/" : "/profile"} className="profile-button">
                                {isProfilePage ? "Главное меню" : "Мой профиль"}
                           </Link>
                            <button onClick={toggleTheme} className="theme-button">
                                {isDarkMode ? "Светлая тема" : "Темная тема"}
                           </button>
                            <button onClick={handleModalOpen} className="edit-profile-button">
                                 Редактировать профиль
                           </button>
                            <button onClick={handleAddAccount} className="add-account-button">
                                Добавить аккаунт
                            </button>
                           {accounts.map(account => (
                               <button
                                   key={account.username}
                                    className={`account-button ${currentAccount === account.username ? 'active' : ''}`}
                                   onClick={() => handleSwitchAccount(account)}
                               >
                                {account.username}
                            </button>
                            ))}
                         </div>
                    )}
                </div>
             ) : (
                <div className="auth-buttons">
                    <button onClick={() => toggleAuthForm(true)} className="login-button">Login</button>
                    <button onClick={() => toggleAuthForm(false)} className="register-button">Register</button>
                </div>
            )}
              {showAuthForm && (
                 <div className="overlay" onClick={closeAuthForm}>
                    <div className="auth-form-container" onClick={(e) => e.stopPropagation()}>
                        <AuthForm
                            onAuth={handleAuth}
                            isLogin={isLogin}
                            setShowAuthForm={setShowAuthForm}
                            setAuth={()=>{}}
                             setUser={()=>{}}
                             accounts={accounts}
                             setAccounts={setAccounts}
                             setCurrentAccount={setCurrentAccount}
                       />
                    </div>
              </div>
            )}
        </nav>
   );
};

export default Navbar;