import React, { useState, useRef, useEffect } from 'react';
import EditProfileForm from "./EditProfileForm";

const UserProfile = ({ user, onLogout, apiUrl }) => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const menuRef = useRef(null);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };
    const closeMenu = () => {
        setIsMenuOpen(false);
    };
    const handleEditProfileClick = () => {
        setIsEditMode(true);
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (menuRef.current && !menuRef.current.contains(event.target)) {
                closeMenu();
            }
        };

        document.addEventListener('mousedown', handleClickOutside);

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div style={{display: "flex", alignItems: 'center', position: 'relative'}} ref={menuRef}>
            <div style={{display: "flex", alignItems: 'center', cursor: "pointer"}} onClick={toggleMenu}>
                {user?.avatarPath && <img style={{width: 30, height: 30, borderRadius: '50%', marginRight: 10}} src={`${apiUrl}${user.avatarPath}`} alt="User Avatar" />}
                <span>{user?.username}</span>
            </div>
            {isMenuOpen && (
                <div style={{ position: 'absolute', top: '100%', right: 0, border: '1px solid #ccc', backgroundColor: 'white', zIndex: 100, padding: '10px'}}>
                    {!isEditMode && <button style={{display: 'block', marginBottom: '5px', border: 'none', background: 'none', textAlign: 'left', padding: 0}} onClick={handleEditProfileClick}>Edit Profile</button>}
                    {!isEditMode && <button style={{display: 'block', border: 'none', background: 'none', textAlign: 'left', padding: 0}} onClick={onLogout}>Logout</button>}
                    {isEditMode && <EditProfileForm user={user} setIsEditMode={setIsEditMode} onCloseMenu={closeMenu} apiUrl={apiUrl} />}
                </div>
            )}
        </div>
    );
};

export default UserProfile;