import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import './CreateContentModal.css';
import VideoUploadForm from './VideoUploadForm';

const CreateContentModal = ({ onClose }) => {
    const [showVideoForm, setShowVideoForm] = useState(false);
     const [showMainContent, setShowMainContent] = useState(true);
    const handleVideoUpload = (videoData) => {
        console.log('Видео загружено:', videoData);
      setShowMainContent(true);
        // Тут будем добавлять логику загрузки видео
    };

   const handleVideoClick = () => {
    setShowVideoForm(true);
        setShowMainContent(false);
  };

  const handleCloseModal = () => {
       setShowVideoForm(false);
      setShowMainContent(true);
        onClose();
  };
   return ReactDOM.createPortal(
       <div className="create-content-modal">
            {showMainContent && (
            <div className="modal-content">
                <h2>Что бы вы хотели создать?</h2>
                <div className="content-options">
                    <button onClick={handleVideoClick}>Видео</button>
                    <button>Изображение</button>
                    <button>Сообщение</button>
                    <button>Рисунок</button>
                 </div>
                <button className="modal-close-button" onClick={handleCloseModal}>X</button>
            </div>
            )}
            {showVideoForm &&
                <VideoUploadForm onClose={() => {
                     setShowVideoForm(false);
                  setShowMainContent(true);
                 }} onVideoUpload={handleVideoUpload}/>
            }
        </div>,
        document.getElementById('modal-root')
    );
};

export default CreateContentModal;