import React, { useState } from 'react';
import UserSearch from './UserSearch';
import ChatWindow from './ChatWindow';
import LastChats from './LastChats';

const Chat = () => {
    const [selectedUser, setSelectedUser] = useState(null);

    const handleUserSelect = (user) => {
        setSelectedUser(user);
    };

    return (
        <div style={{display: 'flex', gap: '10px'}}>
            <LastChats onUserSelect={handleUserSelect} />
            <div>
                <h1>Чат</h1>
                <UserSearch onUserSelect={handleUserSelect} />
                {selectedUser && <ChatWindow selectedUser={selectedUser} />}
            </div>
        </div>
    );
};

export default Chat;